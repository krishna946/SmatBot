// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  // Your web app's Firebase configuration
   firebase :{
    apiKey: "AIzaSyDrEIAw7s8CwXcHc1dvMlOsp_n5zgSsdk8",
    authDomain: "smatbot-abc67.firebaseapp.com",
    databaseURL: "https://smatbot-abc67.firebaseio.com",
    projectId: "smatbot-abc67",
    storageBucket: "smatbot-abc67.appspot.com",
    messagingSenderId: "846964602791",
    appId: "1:846964602791:web:8bad026af9f167a79d2882"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
